package com.example.cle1_amionwong;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class LakawonIsland extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lakawon_island);
    }
}