package com.example.cle1_amionwong;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        ImageView imgOne = findViewById(R.id.Ruins);
        imgOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(main.this, Ruins.class);
                startActivity(i);
            }
        });
        ImageView imgTwo = findViewById(R.id.LakawonIsland);
        imgTwo.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent i = new Intent(main.this, LakawonIsland.class);
                startActivity(i);
            }
        });
        ImageView imgThree = findViewById(R.id.BalayNegrense);
        imgThree.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent i = new Intent(main.this, balaynegrense.class);
                startActivity(i);
            }
        });
        ImageView imgFour = findViewById(R.id.SanSeb);
        imgFour.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent i = new Intent(main.this, sanseb.class);
                startActivity(i);
            }
        });
    }
}